// Import the axios library
const axios = require('axios')
// const movieList = axios.get('http://localhost:3000/movies')
// const movieList = require("./db.json").movies;

const getMovies = async (done) => {
  // get all movies
  const response = await axios.get('http://localhost:3000/movies')
  return done(null, JSON.stringify(response.data))
}

const getMoviesById = async (movieId, done) => {
  // get movie by id
  const response = await axios.get('http://localhost:3000/movies')
  const moviesList = response.data
  const movie = moviesList.find(t => t.id === parseInt(movieId))
  if(!movie) {
    return done("Requested product doesn\'t exist..!", null)
  }
  else{
    return done(null, JSON.stringify(movie))
  }
}

const saveMovie = async (newMovie, done) => {
  // save the details of a movie read from the request body
  const response = await axios.get('http://localhost:3000/movies')
  let moviesList = response.data
  const newMovieId = newMovie.id
  const isMovieExist = moviesList.find(t => t.id === parseInt(newMovieId))
  if(!isMovieExist) {
    moviesList.push(newMovie)
    return done(null, JSON.stringify(newMovie));
  }
  else {
    return done("Movie already exists..!", null)
  }
}

const updateMovie = function (movieId, updateData, done) {
 // update movie details of a specific movie
}

const deleteMovieById = function (movieId, done) {
  // delete a specific movie 
}



module.exports = {
  getMovies,
  getMoviesById,
  saveMovie,
  updateMovie,
  deleteMovieById
}
